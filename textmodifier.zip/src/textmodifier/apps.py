from django.apps import AppConfig


class TextmodifierConfig(AppConfig):
    name = 'textmodifier'
